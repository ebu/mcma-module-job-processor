"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const AWSXRay = require("aws-xray-sdk-core");
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const uuid_1 = require("uuid");
const core_1 = require("@mcma/core");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const data_1 = require("@mcma/data");
const api_1 = require("@mcma/api");
const data_aws_1 = require("@local/data-aws");
const job_cleanup_1 = require("@local/job-cleanup");
const cloudWatchLogsClient = AWSXRay.captureAWSv3Client(new client_cloudwatch_logs_1.CloudWatchLogsClient({}));
const dynamoDBClient = AWSXRay.captureAWSv3Client(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = AWSXRay.captureAWSv3Client(new client_lambda_1.LambdaClient({}));
const loggerProvider = new aws_logger_1.AwsCloudWatchLoggerProvider("job-processor-job-cleanup", (0, aws_logger_1.getLogGroupName)(), cloudWatchLogsClient);
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const dataController = new data_aws_1.AwsDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), (0, data_aws_1.buildDbTableProvider)(false, dynamoDBClient));
async function handler(event, context) {
    const tracker = new core_1.McmaTracker({
        id: (0, uuid_1.v4)(),
        label: "Job Cleanup - " + new Date().toUTCString()
    });
    const logger = await loggerProvider.get(context.awsRequestId, tracker);
    try {
        logger.functionStart(context.awsRequestId);
        const jobCleanup = new job_cleanup_1.JobCleanup(logger, dataController, workerInvoker);
        await jobCleanup.run();
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.awsRequestId);
        await loggerProvider.flush();
    }
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const AWSXRay = require("aws-xray-sdk-core");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const core_1 = require("@mcma/core");
const api_1 = require("@mcma/api");
const client_1 = require("@mcma/client");
const data_1 = require("@mcma/data");
const aws_api_gateway_1 = require("@mcma/aws-api-gateway");
const aws_client_1 = require("@mcma/aws-client");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const data_aws_1 = require("@local/data-aws");
const api_2 = require("@local/api");
const dynamoDBClient = AWSXRay.captureAWSv3Client(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = AWSXRay.captureAWSv3Client(new client_lambda_1.LambdaClient({}));
const secretsManagerClient = AWSXRay.captureAWSv3Client(new client_secrets_manager_1.SecretsManagerClient({}));
const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
const authProvider = new client_1.AuthProvider().add((0, aws_client_1.awsV4Auth)()).add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const loggerProvider = new core_1.ConsoleLoggerProvider("job-processor-api-handler");
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const dataController = new data_aws_1.AwsDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), (0, data_aws_1.buildDbTableProvider)(false, dynamoDBClient));
const jobRoutes = new api_2.JobRoutes(dataController, resourceManagerProvider, workerInvoker);
const jobExecutionRoutes = new api_2.JobExecutionRoutes(dataController, workerInvoker);
const routes = new api_1.McmaApiRouteCollection().addRoutes(jobRoutes).addRoutes(jobExecutionRoutes);
const middleware = [];
if (process.env.MCMA_API_KEY_SECURITY_CONFIG_SECRET_ID) {
    const securityMiddleware = new api_1.McmaApiKeySecurityMiddleware({ secretsProvider });
    middleware.push(securityMiddleware);
}
const restController = new aws_api_gateway_1.ApiGatewayApiController({
    routes,
    loggerProvider,
    middleware
});
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        return await restController.handleRequest(event, context);
    }
    finally {
        logger.functionEnd(context.awsRequestId);
    }
}
exports.handler = handler;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const aws_xray_sdk_core_1 = require("aws-xray-sdk-core");
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const aws_secrets_manager_1 = require("@mcma/aws-secrets-manager");
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_client_1 = require("@mcma/aws-client");
const data_1 = require("@mcma/data");
const api_1 = require("@mcma/api");
const data_aws_1 = require("@local/data-aws");
const worker_2 = require("@local/worker");
const cloudWatchLogsClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_cloudwatch_logs_1.CloudWatchLogsClient({}));
const dynamoDBClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_dynamodb_1.DynamoDBClient({}));
const secretsManagerClient = (0, aws_xray_sdk_core_1.captureAWSv3Client)(new client_secrets_manager_1.SecretsManagerClient({}));
const secretsProvider = new aws_secrets_manager_1.AwsSecretsManagerSecretsProvider({ client: secretsManagerClient });
const authProvider = new client_1.AuthProvider().add((0, aws_client_1.awsV4Auth)()).add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const loggerProvider = new aws_logger_1.AwsCloudWatchLoggerProvider("job-processor-worker", (0, aws_logger_1.getLogGroupName)(), cloudWatchLogsClient);
const dataController = new data_aws_1.AwsDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), (0, data_aws_1.buildDbTableProvider)(true, dynamoDBClient));
const worker = (0, worker_2.buildWorker)(authProvider, loggerProvider, resourceManagerProvider);
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId, event.tracker);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        const workerContext = {
            requestId: context.awsRequestId,
            dataController,
        };
        await worker.doWork(new worker_1.WorkerRequest(event, logger), workerContext);
    }
    catch (error) {
        logger.error("Error occurred when handling operation '" + event.operationName + "'");
        logger.error(error);
    }
    finally {
        logger.functionEnd(context.awsRequestId);
        await loggerProvider.flush();
    }
}

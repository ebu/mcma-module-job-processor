"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.workerQueueHandler = workerQueueHandler;
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_key_vault_1 = require("@mcma/azure-key-vault");
const data_1 = require("@mcma/data");
const api_1 = require("@mcma/api");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const data_azure_1 = require("@local/data-azure");
const worker_2 = require("@local/worker");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("job-processor-worker");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const secretsProvider = new azure_key_vault_1.AzureKeyVaultSecretsProvider();
const authProvider = new client_1.AuthProvider().add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const dataController = new data_azure_1.AzureDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), dbTableProvider);
const worker = (0, worker_2.buildWorker)(authProvider, loggerProvider, resourceManagerProvider);
async function workerQueueHandler(queueItem, context) {
    const queueMessage = queueItem;
    const logger = await loggerProvider.get(context.invocationId, queueMessage.tracker);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(queueMessage);
        const workerContext = {
            requestId: context.invocationId,
            dataController,
        };
        await worker.doWork(new worker_1.WorkerRequest(queueMessage, logger), workerContext);
    }
    catch (error) {
        logger.error(error.message);
        logger.error(error);
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
}

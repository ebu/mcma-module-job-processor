"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const api_handler_1 = require("./api-handler");
const worker_1 = require("./worker");
const job_checker_1 = require("./job-checker");
const job_cleanup_1 = require("./job-cleanup");
functions_1.app.http("api-handler", {
    route: "{*path}",
    methods: ["GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "TRACE", "CONNECT"],
    authLevel: "anonymous",
    handler: api_handler_1.apiHandler
});
functions_1.app.storageQueue("worker", {
    queueName: process.env.WORKER_QUEUE_NAME,
    connection: undefined,
    handler: worker_1.workerQueueHandler,
});
functions_1.app.timer("job-checker", {
    schedule: "0 * * * * *",
    handler: job_checker_1.jobChecker,
});
functions_1.app.timer("job-cleanup", {
    schedule: "0 0 0 * * *",
    handler: job_cleanup_1.jobCleanup,
});

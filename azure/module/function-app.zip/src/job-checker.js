"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jobChecker = jobChecker;
const uuid_1 = require("uuid");
const api_1 = require("@mcma/api");
const core_1 = require("@mcma/core");
const data_1 = require("@mcma/data");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_queue_worker_invoker_1 = require("@mcma/azure-queue-worker-invoker");
const data_azure_1 = require("@local/data-azure");
const job_checker_1 = require("@local/job-checker");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("job-processor-job-checker");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const workerInvoker = new azure_queue_worker_invoker_1.QueueWorkerInvoker();
const dataController = new data_azure_1.AzureDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), dbTableProvider);
async function jobChecker(timer, context) {
    const tracker = new core_1.McmaTracker({
        id: (0, uuid_1.v4)(),
        label: "Job Checker - " + new Date().toUTCString()
    });
    const logger = await loggerProvider.get(context.invocationId, tracker);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(timer);
        const jobChecker = new job_checker_1.JobChecker(logger, dataController, workerInvoker, context.invocationId);
        await jobChecker.run();
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
}

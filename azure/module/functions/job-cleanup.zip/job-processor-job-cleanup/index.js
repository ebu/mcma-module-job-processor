"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const uuid_1 = require("uuid");
const api_1 = require("@mcma/api");
const data_1 = require("@mcma/data");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_queue_worker_invoker_1 = require("@mcma/azure-queue-worker-invoker");
const data_azure_1 = require("@local/data-azure");
const job_cleanup_1 = require("@local/job-cleanup");
const core_1 = require("@mcma/core");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("job-processor-job-cleanup");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const workerInvoker = new azure_queue_worker_invoker_1.QueueWorkerInvoker();
const dataController = new data_azure_1.AzureDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), dbTableProvider);
const handler = async (context, timer) => {
    const tracker = new core_1.McmaTracker({
        id: (0, uuid_1.v4)(),
        label: "Job Cleanup - " + new Date().toUTCString()
    });
    const logger = await loggerProvider.get(context.invocationId, tracker);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(timer);
        const jobCleanup = new job_cleanup_1.JobCleanup(logger, dataController, workerInvoker);
        await jobCleanup.run();
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
};
exports.handler = handler;

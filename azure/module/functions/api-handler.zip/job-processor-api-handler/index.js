"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const api_1 = require("@mcma/api");
const client_1 = require("@mcma/client");
const data_1 = require("@mcma/data");
const azure_cosmos_db_1 = require("@mcma/azure-cosmos-db");
const azure_logger_1 = require("@mcma/azure-logger");
const azure_functions_api_1 = require("@mcma/azure-functions-api");
const azure_key_vault_1 = require("@mcma/azure-key-vault");
const azure_queue_worker_invoker_1 = require("@mcma/azure-queue-worker-invoker");
const data_azure_1 = require("@local/data-azure");
const api_2 = require("@local/api");
const api_3 = require("@local/api");
const loggerProvider = new azure_logger_1.AppInsightsLoggerProvider("job-processor-api-handler");
const dbTableProvider = new azure_cosmos_db_1.CosmosDbTableProvider((0, azure_cosmos_db_1.fillOptionsFromConfigVariables)());
const secretsProvider = new azure_key_vault_1.AzureKeyVaultSecretsProvider();
const authProvider = new client_1.AuthProvider().add((0, client_1.mcmaApiKeyAuth)({ secretsProvider }));
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const workerInvoker = new azure_queue_worker_invoker_1.QueueWorkerInvoker();
const securityMiddleware = new api_1.McmaApiKeySecurityMiddleware({ secretsProvider });
const dataController = new data_azure_1.AzureDataController((0, data_1.getTableName)(), (0, api_1.getPublicUrl)(), dbTableProvider);
const jobRoutes = new api_2.JobRoutes(dataController, resourceManagerProvider, workerInvoker);
const jobExecutionRoutes = new api_3.JobExecutionRoutes(dataController, workerInvoker);
const routes = new api_1.McmaApiRouteCollection().addRoutes(jobRoutes).addRoutes(jobExecutionRoutes);
const restController = new azure_functions_api_1.AzureFunctionApiController({
    routes,
    loggerProvider,
    middleware: [securityMiddleware],
});
const handler = async (context, request) => {
    const logger = await loggerProvider.get(context.invocationId);
    try {
        logger.functionStart(context.invocationId);
        logger.debug(context);
        logger.debug(request);
        return await restController.handleRequest(request);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.invocationId);
        loggerProvider.flush();
    }
};
exports.handler = handler;
